#!/system/bin/sh

TARGET_FILE="/data/adb/tricky_store/target.txt"
INTERVAL=30  # 5秒检测一次

get_all_packages() {
    # 从包管理数据库直接读取所有包名（系统、用户、多开全包涵）
    if [ -f /data/system/packages.list ]; then
        awk '{print $1}' /data/system/packages.list | sort -u
    else
        # 极端情况下文件不存在，回退用 pm 命令遍历所有用户
        for u in $(ls /data/user/ 2>/dev/null | grep -E '^[0-9]+$'); do
            pm list packages --user "$u" 2>/dev/null | cut -d: -f2
        done | sort -u
    fi
}

# 首次写入
pkg_list=$(get_all_packages)
[ -n "$pkg_list" ] && echo "$pkg_list" > "$TARGET_FILE"
prev_list="$pkg_list"

# 后台持续监控变化
while true; do
    sleep "$INTERVAL"
    curr_list=$(get_all_packages)
    if [ "$curr_list" != "$prev_list" ]; then
        echo "$curr_list" > "$TARGET_FILE"
        prev_list="$curr_list"
    fi
done