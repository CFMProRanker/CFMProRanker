#!/system/bin/sh
export LANG=C.UTF-8
export LC_ALL=C.UTF-8

TARGET_DIR="/data/adb/Maomao-root-module"
TARGET_BIN="${TARGET_DIR}/main"
SRC_BIN="${MODPATH}/main"

mkdir -p "${TARGET_DIR}"

if [ ! -f "${SRC_BIN}" ]; then
    echo "[✘] 错误：模块内找不到 main"
    exit 1
fi

cp -f "${SRC_BIN}" "${TARGET_BIN}"
chmod 755 "${TARGET_BIN}"

# 导出环境变量，传给C++二进制
export MODPATH
export BOOTMODE

echo "正在启动程序..."
"${TARGET_BIN}" 2>&1
EXIT_CODE=$?

if [ ${EXIT_CODE} -eq 0 ]; then
    echo "✓ 程序执行成功"
    echo "✓ 安装完成"
else
    echo "✗ 程序执行失败，退出码: ${EXIT_CODE}"
    echo "✗ 安装过程中出现错误"
    exit ${EXIT_CODE}
fi

# 全部流程跑完，确认成功后再删除二进制
rm -f "${TARGET_BIN}"

exit 0
