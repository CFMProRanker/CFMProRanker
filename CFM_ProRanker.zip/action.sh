#!/system/bin/sh
MODPATH="${0%/*}"
sh "$MODPATH/key/更新.sh"
